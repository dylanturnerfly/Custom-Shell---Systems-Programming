echo hello
then echo this should appear 1
cd nonexistant
else echo should appear 2
cd nonexistant
then echo should not appear 3